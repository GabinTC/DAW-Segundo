let tiempoDestruccion = parseInt(prompt("En cuanto quieres que se destruya tu ordenador?"))

setInterval(tiempoDestruccion, 1000)
